# Задание 7. Композиция вместо наследования

`LoggingEmailSender extends EmailSender` привязывает логирование к email. Для retry и metrics пришлось бы делать `RetryLoggingEmailSender` и так далее — комбинации растут.

Вместо этого `LoggingSender`, `MetricsSender`, `RetrySender` — декораторы: они реализуют `NotificationSender` и оборачивают другой `NotificationSender`. Их можно складывать в любом порядке и для любого отправителя (email, console).

## Разница порядков
Отправитель падает два раза, на третий раз успешен.

- **A: Logging(Metrics(Retry(Email)))** — retry внутри. Снаружи виден один вызов: одна пара строк лога и `calls=1, failures=0`. Повторы скрыты.
- **B: Retry(Logging(Metrics(Email)))** — retry снаружи. Логирование и метрики видят каждую попытку: три записи в логе и `calls=3, failures=2`.

Итог: декоратор наблюдает только то, что находится под ним. Порядок оборачивания определяет, что считается «одним вызовом».

## Вывод
```
Порядок A: Logging(Metrics(Retry(Email)))
  LOG: отправка user@mail.com
  Email -> user@mail.com: Привет
  LOG: успех
  metrics: calls=1, failures=0
Порядок B: Retry(Logging(Metrics(Email)))
  LOG: отправка user@mail.com
  LOG: ошибка smtp недоступен
  LOG: отправка user@mail.com
  LOG: ошибка smtp недоступен
  LOG: отправка user@mail.com
  Email -> user@mail.com: Привет
  LOG: успех
  metrics: calls=3, failures=2
```
