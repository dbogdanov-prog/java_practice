# Задание 8. Нарушение LSP

**Проблема.** `ReadOnlyCourseRepository extends CourseRepository` объявляет, что умеет всё, что умеет `CourseRepository`, но `save` выбрасывает исключение. Клиент, который принимает `CourseRepository` и вызывает `save`, ломается при подстановке подтипа. Подтип сузил обещание базового типа (см. `OldDesign.java`).

**Решение.** Интерфейс разделён по возможностям:
- `CourseReader` — чтение;
- `CourseWriter` — запись;
- `CourseRepository extends CourseReader, CourseWriter` — полный доступ.

`ReadOnlyCourseRepository` реализует только `CourseReader`. Метод, которому нужна запись, принимает `CourseWriter`, и передать ему read-only реализацию компилятор не даст. Ошибка перенесена из времени выполнения в время компиляции.

## Вывод
```
Старый дизайн: save упал: read-only
Course[id=1, title=Java]
Course[id=2, title=SQL]
Course[id=1, title=Java]
Course[id=2, title=SQL]
```
