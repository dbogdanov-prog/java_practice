# Задание 6. Переопределение без случайной перегрузки

В `Main.java` все переопределения помечены `@Override`: `Book.price/describe/handle`, `Point.equals(Object)`.

Три типичные ошибки (файл `broken/Bad.java.txt`, в сборку не входит). С `@Override` компилятор их ловит:

```
Bad.java:7: error: method does not override or implement a method from a supertype
Bad.java:8: error: describe() in Bad cannot override describe() in Product
Bad.java:9: error: price() in Bad cannot override price() in Product
Bad.java:9: error: method does not override or implement a method from a supertype
```

1. Параметр: `equals(Bad)` вместо `equals(Object)` — это перегрузка, а не переопределение.
2. Доступ: нельзя сузить `public` до package-private.
3. Возвращаемый тип: `int` несовместим с `double`.

## Когда без аннотации вызывается не тот метод
- `BookBefore.handle(String)` задуман как переопределение `handle(Object)`, но это перегрузка. Через ссылку `Product` вызывается `Product.handle`.
- `PointBefore.equals(PointBefore)` — перегрузка. `List.contains` вызывает `equals(Object)` из `Object`, поэтому находит объект только по ссылке и возвращает `false`.

С `@Override` оба случая не компилировались бы.

## Вывод
```
12.0 book
Book.handle
Product.handle
false
true
```
