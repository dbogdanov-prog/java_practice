# Задание 15. Расширяемый движок правил CourseHub

## Диаграмма зависимостей

```mermaid
classDiagram
    class EnrollmentService {
        +enroll(Student, Course) EnrollmentDecision
    }
    class EnrollmentRule {
        <<interface>>
        +check(EnrollmentRequest) RuleResult
    }
    class CompositeRule {
        <<abstract>>
    }
    class RuleResult {
        <<sealed>>
    }
    class EnrollmentDecision {
        <<sealed>>
    }
    EnrollmentService --> EnrollmentRule : использует
    EnrollmentService --> RuleResult : switch
    EnrollmentService --> EnrollmentDecision : создаёт
    EnrollmentRule --> RuleResult : возвращает
    EnrollmentRule <|.. NotBlockedRule
    EnrollmentRule <|.. AgeRule
    EnrollmentRule <|.. PrerequisiteRule
    EnrollmentRule <|.. PaymentRule
    EnrollmentRule <|.. ScholarshipRule
    EnrollmentRule <|.. CapacityRule
    EnrollmentRule <|.. CompositeRule
    CompositeRule <|-- AllOf
    CompositeRule <|-- AnyOf
    CompositeRule o--> EnrollmentRule : содержит
    RuleResult <|.. Pass
    RuleResult <|.. Fail
    RuleResult <|.. Defer
    EnrollmentDecision <|.. Accepted
    EnrollmentDecision <|.. Rejected
    EnrollmentDecision <|.. WaitListed
```

`EnrollmentService` зависит только от `EnrollmentRule` и от закрытых типов результатов. Конкретные правила он не знает.

## Реализации правил (8)
`NotBlockedRule`, `AgeRule`, `PrerequisiteRule`, `PaymentRule`, `ScholarshipRule`, `CapacityRule` и композиты `AllOf`, `AnyOf`. Кроме того, в `Main` правило задано лямбдой.

Результат правила — `RuleResult`: `Pass`, `Fail(reason)`, `Defer(reason)` (например, нет мест → лист ожидания). Результат сервиса — `EnrollmentDecision`: `Accepted`, `Rejected`, `WaitListed`.

Композиция: `AllOf` — любой `Fail` даёт `Fail`, иначе любой `Defer` даёт `Defer`, иначе `Pass`. `AnyOf` — любой `Pass` даёт `Pass`, иначе `Defer`, иначе `Fail` со всеми причинами. Композиты сами являются правилами, поэтому вкладываются друг в друга.

## Dynamic dispatch
В `Main` список `List<EnrollmentRule>` обходится циклом: `rule.check(request)` вызывает реализацию по фактическому классу. `EnrollmentService` вызывает `rule.check`, не зная, правило это простое или композит.

## Записка

**Где уместно наследование.** `CompositeRule` — абстрактный базовый класс для `AllOf` и `AnyOf`: у них общее состояние (список правил) и вспомогательные методы сбора результатов, а отношение «является правилом» настоящее. Иерархия неглубокая (один уровень), подклассы отличаются только способом комбинирования.

**Где выбрана композиция.**
- Правила объединяются через `AllOf` и `AnyOf`, а не подклассами вида `AgeAndPaymentRule`. Комбинации задаются при сборке движка, а не в иерархии классов.
- Сервис получает правило в конструкторе и не наследуется от конкретной проверки.
- `EnrollmentRule` — открытый интерфейс: новое правило, в том числе лямбда, добавляется без изменения существующего кода.

**Какие гарантии даёт sealed-граница.** `RuleResult` и `EnrollmentDecision` закрыты, поэтому:
- набор вариантов известен компилятору, а `switch` в `EnrollmentService` и `Main.show` проверяется на полноту без `default`;
- новый вариант (например, `RuleResult.Review`) вызывает ошибку компиляции во всех `switch`, где его не обработали, и ничего не пропускается молча;
- посторонний код не может добавить свой вариант результата и нарушить протокол между правилами и сервисом.

Цена: закрытый тип нельзя расширить извне. Поэтому закрытыми сделаны только результаты, у которых набор исходов фиксирован, а правила оставлены открытыми.

## Вывод
```
== Правила по отдельности (dynamic dispatch через EnrollmentRule)
NotBlockedRule -> Pass[]
AgeRule -> Pass[]
PrerequisiteRule -> Fail[reason=не пройдены [Java Basics]]
PaymentRule -> Fail[reason=нет оплаты]
ScholarshipRule -> Fail[reason=нет стипендии]
CapacityRule -> Defer[reason=нет мест]
== Движок: allOf(..., anyOf(Payment, Scholarship), Capacity)
Анна: принят
Боря: отказ (возраст меньше 16)
Вера: отказ (не пройдены [Java Basics]; нет оплаты; нет стипендии)
Глеб: принят
Егор: отказ (студент заблокирован)
-- курс без мест
Анна: лист ожидания (нет мест)
Боря: отказ (возраст меньше 16)
== Новое правило без изменения сервиса
Анна: принят
Глеб: отказ (нечётный возраст)
```
