# Задание 12. Sealed-иерархия результата

`EnrollmentResult` — `sealed interface` с вариантами `Accepted`, `Rejected`, `WaitListed`. В `Main.describe` используется `switch`-выражение по всем вариантам без `default`.

## Добавление нового permitted-типа
Добавлен `Cancelled`: в `permits` и новый файл `Cancelled.java`. Если не добавить ветку в `switch`, компиляция падает:

```
Main.java:5: error: the switch expression does not cover all possible input values
        return switch (result) {
               ^
```

Компилятор потребовал изменение **в одном месте — в `switch` в `Main.describe`**. Других мест править не пришлось: в коде нет `instanceof`-цепочек и `default`, которые могли бы незаметно проглотить новый вариант. После добавления `case Cancelled c` код собирается.

## Вывод
```
Анна: принят
Боря: отказ (возраст)
Вера: в листе ожидания, место 3
Глеб: запись отменена
```
