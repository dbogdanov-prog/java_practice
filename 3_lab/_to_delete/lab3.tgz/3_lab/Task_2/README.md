# Задание 2. Dynamic dispatch на бумаге

Иерархия: `NotificationSender` → `EmailSender`, `ConsoleSender`.
В `NotificationSender` две перегрузки: `send(String)` и `send(Object)`.
`EmailSender` переопределяет `send(String)` и добавляет новую перегрузку `send(int)`.
`ConsoleSender` переопределяет обе.

Вызов разбирается в два шага:
1. **Overload resolution (compile-time)** — по статическому типу ссылки и типам аргументов выбирается сигнатура.
2. **Override dispatch (runtime)** — для выбранной сигнатуры вызывается реализация по фактическому классу объекта.

| # | Вызов | Сигнатура (compile-time) | Реализация (runtime) |
|---|-------|--------------------------|----------------------|
| 1 | `NotificationSender a = new EmailSender(); a.send("hi")` | `send(String)` | `EmailSender.send(String)` |
| 2 | `a.send((Object) "hi")` | `send(Object)` | `NotificationSender.send(Object)` — Email его не переопределяет |
| 3 | `a.send(5)` | `send(Object)` (boxing), `send(int)` через `NotificationSender` не виден | `NotificationSender.send(Object)` |
| 4 | `EmailSender b; b.send(5)` | `send(int)` (точное совпадение) | `EmailSender.send(int)` |
| 5 | `b.send("hi")` | `send(String)` | `EmailSender.send(String)` |
| 6 | `NotificationSender c = new ConsoleSender(); c.send("hi")` | `send(String)` | `ConsoleSender.send(String)` |
| 7 | `c.send((Object) "hi")` | `send(Object)` | `ConsoleSender.send(Object)` |
| 8 | `c.send(5)` | `send(Object)` | `ConsoleSender.send(Object)` |

Главное: приведение `(Object)` меняет только выбор сигнатуры на этапе компиляции. Фактический тип объекта остаётся `EmailSender`, но у него для `send(Object)` нет своей реализации.

## Вывод
```
EmailSender.send(String): hi
NotificationSender.send(Object): hi
NotificationSender.send(Object): 5
EmailSender.send(int): 5
EmailSender.send(String): hi
ConsoleSender.send(String): hi
ConsoleSender.send(Object): hi
ConsoleSender.send(Object): 5
```
